- [x] Create Kubernetes deployment for Fleet Server
- [x] Create Kubernetes service for Fleet Server
- [x] Create Kubernetes secret for Fleet Server TLS certificate and key
- [x] Create Kubernetes secret for Elasticsearch service token
- [x] Create documentation and deployment guide

