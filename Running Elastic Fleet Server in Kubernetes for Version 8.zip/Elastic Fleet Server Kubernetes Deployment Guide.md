# Elastic Fleet Server Kubernetes Deployment Guide

This guide provides the necessary Kubernetes configurations and steps to deploy Elastic Fleet Server version 8.17.3 in your Kubernetes environment. This setup is designed to manage Elastic Agents in a private location.

## Prerequisites

Before you begin, ensure you have the following:

*   A running Kubernetes cluster.
*   `kubectl` configured to connect to your cluster.
*   An Elasticsearch cluster (version 8.17.3 or later) accessible from your Kubernetes cluster.
*   Kibana (version 8.17.3 or later) accessible from your Kubernetes cluster.
*   A Fleet policy configured in Kibana with the Fleet Server integration.
*   A service token generated in Kibana for authenticating the Fleet Server with Elasticsearch.
*   TLS certificates and keys for the Fleet Server HTTPS endpoint. These certificates must be valid for the hostname/URL that Elastic Agents will use to access the Fleet Server.
*   The CA certificate (or certificates) associated with your Elasticsearch cluster, if it uses certificates signed by a private or intermediate CA.
*   The Elasticsearch CA trusted fingerprint.

## Configuration Files

This deployment consists of the following Kubernetes manifest files:

1.  `fleet-server-deployment.yaml`: Defines the Deployment for the Fleet Server pod.
2.  `fleet-server-service.yaml`: Defines the Service to expose the Fleet Server within the cluster.
3.  `fleet-server-tls-secret.yaml`: Stores the TLS certificate and key for the Fleet Server.
4.  `fleet-server-service-token-secret.yaml`: Stores the service token for Fleet Server authentication.

## Deployment Steps

Follow these steps to deploy the Elastic Fleet Server:

### Step 1: Prepare Secrets

First, you need to create the Kubernetes Secrets for the Fleet Server's TLS certificate and key, and the Elasticsearch service token.

**1.1. Create TLS Secret for Fleet Server:**

Replace `<BASE64_ENCODED_FLEET_SERVER_CERT>` and `<BASE64_ENCODED_FLEET_SERVER_KEY>` with the base64 encoded values of your Fleet Server's TLS certificate and private key, respectively. You can encode them using `base64 -w 0 <file_name>`.

```yaml
# fleet-server-tls-secret.yaml
apiVersion: v1
kind: Secret
metadata:
  name: fleet-server-tls
type: kubernetes.io/tls
data:
  tls.crt: <BASE64_ENCODED_FLEET_SERVER_CERT>
  tls.key: <BASE64_ENCODED_FLEET_SERVER_KEY>
```

Apply the secret:

```bash
kubectl apply -f fleet-server-tls-secret.yaml
```

**1.2. Create Service Token Secret:**

Replace `<BASE64_ENCODED_FLEET_SERVER_SERVICE_TOKEN>` with the base64 encoded value of your Fleet Server's service token.

```yaml
# fleet-server-service-token-secret.yaml
apiVersion: v1
kind: Secret
metadata:
  name: fleet-server-secret
type: Opaque
data:
  service-token: <BASE64_ENCODED_FLEET_SERVER_SERVICE_TOKEN>
```

Apply the secret:

```bash
kubectl apply -f fleet-server-service-token-secret.yaml
```

**1.3. Create Elasticsearch Credentials Secret (if not already present):**

If you don't have an existing secret for Elasticsearch credentials, create one. Replace `<BASE64_ENCODED_ELASTICSEARCH_PASSWORD>` with the base64 encoded password for your Elasticsearch user (e.g., `elastic`).

```yaml
# elasticsearch-credentials-secret.yaml
apiVersion: v1
kind: Secret
metadata:
  name: elasticsearch-credentials
type: Opaque
data:
  password: <BASE64_ENCODED_ELASTICSEARCH_PASSWORD>
```

Apply the secret:

```bash
kubectl apply -f elasticsearch-credentials-secret.yaml
```

### Step 2: Deploy Fleet Server Service

This service exposes the Fleet Server within your Kubernetes cluster.

```yaml
# fleet-server-service.yaml
apiVersion: v1
kind: Service
metadata:
  name: fleet-server
  labels:
    app: fleet-server
spec:
  selector:
    app: fleet-server
  ports:
    - protocol: TCP
      port: 8220
      targetPort: 8220
      name: fleet-server
```

Apply the service:

```bash
kubectl apply -f fleet-server-service.yaml
```

### Step 3: Deploy Fleet Server Deployment

This deployment runs the Elastic Agent configured as a Fleet Server.

**Important:** Before applying, replace `<YOUR_ELASTICSEARCH_CA_FINGERPRINT>` in `fleet-server-deployment.yaml` with the actual trusted fingerprint of your Elasticsearch CA. You can find this in Kibana under **Fleet -> Settings -> Elasticsearch output**.

```yaml
# fleet-server-deployment.yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: fleet-server
  labels:
    app: fleet-server
spec:
  replicas: 1
  selector:
    matchLabels:
      app: fleet-server
  template:
    metadata:
      labels:
        app: fleet-server
    spec:
      containers:
      - name: fleet-server
        image: docker.elastic.co/elasticagent/elastic-agent:8.17.3
        env:
          - name: FLEET_SERVER_ENABLE
            value: "true"
          - name: FLEET_SERVER_SERVICE_TOKEN
            valueFrom:
              secretKeyRef:
                name: fleet-server-secret
                key: service-token
          - name: FLEET_URL
            value: "https://fleet-server.default.svc:8220"
          - name: ELASTICSEARCH_HOST
            value: "https://elasticsearch.default.svc:9200"
          - name: ELASTICSEARCH_USERNAME
            value: "elastic"
          - name: ELASTICSEARCH_PASSWORD
            valueFrom:
              secretKeyRef:
                name: elasticsearch-credentials
                key: password
          - name: ELASTICSEARCH_CA_TRUSTED_FINGERPRINT
            value: "<YOUR_ELASTICSEARCH_CA_FINGERPRINT>"
          - name: FLEET_SERVER_INSECURE_HTTP
            value: "false"
        ports:
          - containerPort: 8220
            name: fleet-server
        volumeMounts:
          - name: fleet-server-certs
            mountPath: /etc/pki/fleet-server/certs
            readOnly: true
      volumes:
        - name: fleet-server-certs
          secret:
            secretName: fleet-server-tls
```

Apply the deployment:

```bash
kubectl apply -f fleet-server-deployment.yaml
```

## Important Notes

*   **Elasticsearch and Kibana Connectivity:** Ensure your Fleet Server pods can reach your Elasticsearch and Kibana instances. Adjust `ELASTICSEARCH_HOST` and `FLEET_URL` in the deployment accordingly if your services are not named `elasticsearch` and `fleet-server` in the `default` namespace.
*   **TLS Certificates:** The TLS certificates for the Fleet Server must be correctly generated and include the Fleet Server's hostname/URL in the Subject Alternative Name (SAN). Elastic Agents will use this URL to connect to the Fleet Server.
*   **Elasticsearch CA Fingerprint:** The `ELASTICSEARCH_CA_TRUSTED_FINGERPRINT` is crucial for the Fleet Server to trust your Elasticsearch instance. Make sure to provide the correct fingerprint.
*   **Service Account and RBAC:** For production environments, it is highly recommended to create a dedicated Kubernetes Service Account and apply appropriate Role-Based Access Control (RBAC) policies to restrict the permissions of the Fleet Server pods.
*   **Scalability:** For high availability and scalability, consider increasing the `replicas` count in the `fleet-server-deployment.yaml` and implementing a load balancer if necessary.
*   **Monitoring:** Monitor the Fleet Server logs and metrics to ensure it is operating correctly and managing agents as expected.


